const express = require('express');
const {
    Server
} = require('socket.io');
const {
    SerialPort,
    ReadlineParser
} = require('serialport');
const app = express();
const httpServer = app.listen(5050);
const ioServer = new Server(httpServer);
let c=0;
let d = 0;

const staticController = express.static('public-controller');
const staticDisplay = express.static('public-display');
const staticGame = express.static('public-Game');

app.use('/controller', staticController);
app.use('/display', staticDisplay);

app.use(express.json());


const protocolConfiguration = {
    path: 'COM3',
    baudRate: 9600
}

const port = new SerialPort(protocolConfiguration);
const parser = port.pipe(new ReadlineParser());


ioServer.on('connection', (socket) => {


    socket.on('start', (screens) => {
        socket.broadcast.emit('start', screens);
    });

    socket.on('shot', (object) => {
        socket.broadcast.emit('shot', object);
    });

    socket.on('screens', (screens) => {
        socket.broadcast.emit('screens', screens);
    });

    socket.on('win', (boolean) => {
        socket.broadcast.emit('win', boolean);
    });

    socket.on('email', (email) => {
        socket.broadcast.emit('email', email);
    });

    socket.on('emailSent', (boolean) => {
        socket.broadcast.emit('emailSent', boolean);
    });


});

parser.on('open', function (){
    console.log("Conection sucessfull");

});

parser.on('data', (data) => {

    // Create the array
    let dataArray = data.split(' ');
    console.log(dataArray);
    let prube = data.split(' ');
    // Parse the Strings to Integer
    let left = parseInt(prube);
    let shoot = parseInt(prube);
    let right = parseInt(prube);
    let infra = parseInt(prube);
    //console.log(characterMessage);
    // Emit the message using WebSocket to the client
    if (shoot == 3) {
        ioServer.emit('start', '1' );
        c=1;
        d+=c;
    }
    if (left == 1) {
        ioServer.emit('moveBall', 'left');
        ioServer.emit('moveS', '1');

    } else if (right == 2) {
        ioServer.emit('moveBall', 'right' );
        ioServer.emit('moveS', '2');
        
    }
    else{
        ioServer.emit('moveBall', 'stop' );
    }

    if (infra == 4){
        ioServer.emit('presentation', '1' );
    }
    console.log(d);
    if(d==2){
        ioServer.emit('entrar', '1' );
    }else if(d>=3){
        ioServer.emit('shot', true);
    }
});

port.on('err', function (err){
    console.log(err);
});