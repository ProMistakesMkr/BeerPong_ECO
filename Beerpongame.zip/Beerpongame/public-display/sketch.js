
let socket = io();

let ball = new Ball(30, 950, 1000);

let balls = [];

let move

let numberOfBalls = 0;

let mainImg;

let ballImg;

let winnerImg;

let barrelOnImg;

let barrelImg;

let celebrating;

let starter = false;

let barrels = [];

let waitingImg;

let emailSent;

let endScreen;

let expect;

let moveState = '';

let on = 0;

let beergif = 0;

let scenarios = 0;

let sel;

let beer = 0;

let zero=0;

let cont=0;

let c = 0;

function preload() {

  mainImg = loadImage('./assets/juegos.png');
  barrelImg0 = loadImage('./assets/Group-3.png')
  barrelImg1 = loadImage('./assets/Group-1.png')
  barrelImg2 = loadImage('./assets/Group.png')
  barrelImg3 = loadImage('./assets/Vector.png')
  barrelImgOn = loadImage('./assets/barrilOn.png')
  ballImg = loadImage('./assets/top.png')
  waitingImg = loadImage('./assets/Pantalla_inicio.png')
  winnerImg = loadImage('./assets/Codigo QR.png')
  endScreen = loadImage('./assets/Codigo QR.png')
  start_button = loadImage('./assets/jugar.png');
  gif = loadImage('./assets/gif.gif');
  expect = loadImage('./assets/game_back.png');
  sel = loadImage ('./assets/seleccion.png');
}

let barrel = new Barrel(200, 200);
let barrel2 = new Barrel(600, 400);
let barrel3 = new Barrel(0, 600);
let barrel4 = new Barrel(800, 800);


function setup() {

  //Canvas settings
  createCanvas(1550, 1100);

}

function draw() {

  background(255);

  socket.on('presentation', (number) => {
    beergif = number;
  })

  socket.on('start', (number)=>{
    on = number;
  })
  
  socket.on('entrar', (number)=>{
    c = number;
  })
  if(c==1){
    on=2;
  }

 if(beergif == 1){
  image(sel, 0, 0);
    socket.on('presentation', (number) => {
      beer = number;
    })
  if(on == 0){
    image(waitingImg, 0, 0);
    image(start_button, 850, 580, 300, 120);
  }
  else if(on == 1){
    socket.on('moveS', (direction) =>{
      move = direction;
    })
    fill(255,0,0,50);
    if(move==1){
      zero=-1;
      wait(200);
      move=0;
    }else if(move==2){
      zero=1;
      wait(200);
      move=0;
    }else{
      zero=0;
    }
    cont+=zero;
    if(cont==0){
      b0=rect(560, 280, 100, 320, 20);
    }else if (cont==1){
      b1=rect(766, 280, 100, 320, 20);
    }else if (cont==2){
      b2=rect(965, 280, 100, 320, 20);
    }else if (cont==3){
      b3=rect(1180, 280, 100, 320, 20);
    }else{
      cont=0;
    }
    text(cont, 80, 65);
    //scenario to choose
  }
  else if (on == 2) {

    image(mainImg, 0, 0, width, height);


    barrel.drawBarrel(barrelImg0, barrelImgOn);
    barrel.move();
    barrel.changeSpeed();

    barrel2.drawBarrel(barrelImg1, barrelImgOn);
    barrel2.move();
    barrel2.changeSpeed();

    barrel3.drawBarrel(barrelImg2, barrelImgOn);
    barrel3.move();
    barrel3.changeSpeed();


    barrel4.drawBarrel(barrelImg3, barrelImgOn);
    barrel4.move();
    barrel4.changeSpeed();

    switch (moveState) {
      case 'left':

        ball.posX -= 2;

        break;

      case 'right':

        ball.posX += 2;

        break;

      default:
        break;
    }



    //console.log(numberOfBalls);
    ball.drawBall(ballImg);
    ball.move();


    if (dist(ball.getX(), ball.getY(), barrel.getX(), barrel.getY()) < 100) {
      console.log("choque")
      ball.setPressed(true);
      barrel.setPressed(true)
    }

    if (dist(ball.getX(), ball.getY(), barrel2.getX(), barrel2.getY()) < 100) {
      console.log("choque")
      ball.setPressed(true);
      barrel2.setPressed(true)
    }

    if (dist(ball.getX(), ball.getY(), barrel3.getX(), barrel3.getY()) < 100) {
      console.log("choque")
      ball.setPressed(true);
      barrel3.setPressed(true)
    }

    if (dist(ball.getX(), ball.getY(), barrel4.getX(), barrel4.getY()) < 100) {
      console.log("choque")
      ball.setPressed(true);
      barrel4.setPressed(true)
    }

    if (barrel.getPressed() === true && barrel2.getPressed() === true && barrel3.getPressed() === true && barrel4.getPressed() === true) {
      image(winnerImg, 0, 0)
      socket.emit('win', true);
    }

  }
 }else{
  image(expect, 0, 0);
  image(gif, width/6, height/6, width/2, height/2);
 }

  socket.on('emailSent', (boolean) => {
    emailSent = boolean
  })

  if (emailSent === true) {

    image(endScreen, 0, 0)
  }

}

socket.on('shot', (number) => {
  console.log(number);
  ball.setPressed(number);
})

socket.on('moveBall', (direction) => {
  /*ball.setPressed(number);*/

  switch (direction) {
    case 'left':
      console.log('left');

      moveState = 'left';
      break;
    case 'right':
      console.log('right');

      moveState = 'right';
      break;

    case 'stop':

      moveState = ' ';
      break;


    default:
      break;
  }


})


function wait(time)
{
start = millis()
do
{
  current = millis();
}
while(current < start + time)
}









