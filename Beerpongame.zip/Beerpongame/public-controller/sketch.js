let socket = io();

let mainImg;

let startButton;

let screens = 0;

let shots = 0;

let onScreen;

let button;

let emailScreen;

let win;

let winBoolean;

let emailInput;

let endImg;

let c = false;

function setup() {

    frameRate(60);
    createCanvas(350, 650);

    mainImg = loadImage('assets/mainPhone.png');
    send = loadImage('assets/Group 17.png');
    emailScreen = loadImage('assets/Pantalla de correo.png')
    endImg = loadImage('./assets/Pantalla final.png')


    emailInput = createInput('');
    emailInput.position(65, 340);
    emailInput.size(228, 30, 5);
    emailInput.input(myInputEmail);

    emailInput.style('display', 'none');
}



function draw() {
    background(255);
    socket.on('win', (boolean)=>{
        c = boolean;
      })
    switch (c) {
        case false:
            break;
        case true:
            
            //mostrar casilla del email
            emailInput.style('display', 'block');
            image(emailScreen,0,0, 350, 650)
            image(send, 135, 390, 90, 45)
            if(mousePressed === true && mouseX>=135 && mouseX<=135+90 && mouseY>=390 && mouseY<=390+45){
                c=2
            }
            break;
        case 2:
            alert("Gracias por participar, tu correo ha sido enviado")
            emailInput.style('display', 'none');
            image(endImg,0,0, 350, 650)
            break;
    }

    socket.on('win', (boolean) => {
        win = boolean
    })

    if (win === true) {
        
        winBoolean = true;
    }
}

function myInputEmail(){
    myEmail = this.value();
}

function mouseClicked() {
    if(mouseX>=135 && mouseX<=135+90 && mouseY>=390 && mouseY<=390+45){
        c=2
    }
  }

function mousePressed() { 

    switch (screens) {
        case 0:
            
            if (dist(mouseX, mouseY, 180, 450) < 300) {
                screens = 1;
            }
            
            break;
        
        case 1:
            
            if (dist(mouseX, mouseY, 175, 450) < 100) {
                shots++;
                console.log(shots)
                socket.emit('shot', true);
            }

            break;
        
        case 2:

            if (mouseX > 120 && mouseY > 548
                && mouseX < 228 && mouseY < 584) {
                
                    screens=3;
            }
            console.log(mouseX + " " + mouseY)
            socket.emit('emailSent', true);
            break;

        case 3:

            console.log(mouseX + " " + mouseY)
            break;
}

}

    function counter() { 

    if (frameCount % 15 === 0 ) { 
      timer++;
      console.log(timer)
    }
  }
  